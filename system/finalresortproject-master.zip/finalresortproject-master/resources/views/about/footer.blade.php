<footer>
  <div class="footer">
    <div class="container">
      <div class="row">
        </div>
    </div>
  </div>
  <div class="copyright">
    <div class="container">
      <div class="row">
        </div>
    </div>
  </div>
</footer>