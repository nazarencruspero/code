
@extends('layouts.app')

@section('styles')
  @endsection

@section('content')
  <div class="about">
    <div class="container-fluid">
      <div class="row">
        </div>
    </div>
  </div>
@endsection

@section('scripts')
  @endsection