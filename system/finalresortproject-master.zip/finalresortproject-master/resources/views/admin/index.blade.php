<!DOCTYPE html>
<html>
  <head> 
    @include('admin.css')
  </head>
  <body>
   @include('admin.header')
   <!--sidebar -->
@include('admin.sidebar')
      <!-- Sidebar Navigation end-->
<!-- body atarts here--> 

@include('admin.body')
<!-- body ends here--> 

        @include('admin.footer')
        </body>
</html>