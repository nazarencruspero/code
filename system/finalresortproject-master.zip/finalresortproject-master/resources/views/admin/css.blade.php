<meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Beach Resort Management</title></title>
  <meta name="description"   
 content="">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="robots" content="all,follow">

  <link rel="stylesheet" href="admin/vendor/bootstrap/css/bootstrap.min.css">

  <link rel="stylesheet" href="admin/vendor/font-awesome/css/font-awesome.min.css">

  <link rel="stylesheet" href="admin/css/font.css">   


  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Muli:300,400,700">

  <link rel="stylesheet" href="admin/css/style.default.css" id="theme-stylesheet">

  <link rel="stylesheet" href="admin/css/custom.css">

  <link rel="shortcut icon" href="admin/img/favicon.ico">

  <link rel="stylesheet" href="admin/css/responsive.css">